
<link rel="stylesheet" href="CSS/about_us.css" type="text/css">
<div class="about-section">
  <h1>About Project</h1>
  <p>Our inclusive website caters to the needs of the differently abled community by offering a platform where they can request for tasks such as grocery shopping, taxi services, and household help.</p>
</div>

<h2 style="text-align:center">Our Team</h2>
<div class="row">
  <div class="column">
    <div class="card">
      <div class="container">
        <h2>M Darshan</h2>
        <p class="title">Team member 1</p>
        <p>+91 7010212186</p>
        <p>darsh18@gmail.com</p>
      </div>
    </div>
  </div>

<div class="row">
  <div class="column">
    <div class="card"> 
        <div class="container">
        <h2>Rohan K Manjunath</h2>
        <p class="title">Team member 2</p>
        <p>+91 9980212354</p>
        <p>rohan6@gmail.com</p>
      </div>
    </div>
  </div>

  <div class="row">
  <div class="column">
    <div class="card"> 
        <div class="container">
        <h2>Madhu H S</h2>
        <p class="title">Team member 3</p>
        <p>+91 9980223454</p>
        <p>madhu16@gmail.com</p>
      </div>
    </div>
  </div>

