<link rel="stylesheet" href="css/contact_us.css" type="text/css">

</style>
</head>
<body>

<h1>REQUEST ASSITANCE</h1>
<h4>The Request Assistance page aims to streamline the process of seeking help and support, ensuring that differently abled individuals can easily communicate their needs. By providing a well-designed form with clear instructions and essential elements, we strive to make the process accessible, user-friendly, and efficient.</h4>

<div class="container">
  <form action="/action_page.php">
    <label for="fname">First Name</label>
    <input type="text" id="fname" name="firstname" placeholder="Your name..">

    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="lastname" placeholder="Your last name..">

    <label for="country">Location</label>
    <select id="country" name="country">
      <option value="india">Bengaluru</option>
      <option value="australia">Mysore</option>
      <option value="italy">Mandya</option>
    </select>

    <label for="subject">Explain the Task </label>
    <textarea id="subject" name="subject" placeholder="Describe the task to be performed.." style="height:150px"></textarea>

    <label for="subject">Full Address</label>
    <textarea id="subject" name="subject" placeholder="Give detailed Address.." style="height:150px"></textarea>

    <input type="submit" value="Submit">
  </form>
</div>

</body>
</html>