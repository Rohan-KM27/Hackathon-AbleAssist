<?php
	session_start();
?>
<html>
	<head>
		<title>
			Welcome Volunteer
		</title>
		<link rel="stylesheet" type="text/css" href="css/style.css"/>
		<link rel="stylesheet" href="font-awesome-4.7.0\css\font-awesome.min.css">
	</head>
	<body>
	<html>
<head>
<style>
body {
  background-image: url("images/admin.jpg");
  background-repeat: no-repeat;
  background-size: 1800px 800px;
}
</style>
</head>
<body>
		<img class="logo" src="images/logo1.jpg"/> 
		<h1 id="title">
			      AbleAssist	</h1>
		<div>
			<ul>
				<li><a href="admin_homepage.php"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
				<li><a href="admin_homepage.php"><i class="fa fa-desktop" aria-hidden="true"></i> Dashboard</a></li>
				<li><a href="logout_handler.php"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a></li>
			</ul>
		</div>
		<h2>Welcome Volunteer, we are delighted to have you!</h2>
		<table cellpadding="5">
			
			<tr>
				<td class="admin_func"><a href="admin_view_booked_tickets.php"><i class="fa fa-hand-paper-o" aria-hidden="true"></i> View Taxi Bookings</a>
				</td>
			</tr>
			<tr>
				<td class="admin_func"><a href="add_flight_details.php"><i class="fa fa-hand-paper-o" aria-hidden="true"></i> Add Taxi Details</a>
				</td>
			</tr>
			<tr>
				<td class="admin_func"><a href="delete_flight_details.php"><i class="fa fa-hand-paper-o" aria-hidden="true"></i> Delete Taxi Details</a>
				</td>
			</tr>
			<tr>
				<td class="admin_func"><a href="activate_jet_details.php"><i class="fa fa-hand-paper-o" aria-hidden="true"></i> On-Duty Taxi</a>
				</td>
			</tr>
			<tr>
				<td class="admin_func"><a href="deactivate_jet_details.php"><i class="fa fa-hand-paper-o" aria-hidden="true"></i> Off-Duty Taxi</a>
				</td>
			</tr>
		</table>
	</body>
</html>